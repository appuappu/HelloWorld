# python-for-everybody-solutions
Solutions to Python for Everybody: Exploring Data using Python 3 by Charles Severance: https://www.py4e.com/book. Only exercises requiring written code are included. Multiple choice and extended response questions have been omitted.
The book's Github can be found at https://github.com/csev/py4e.
For solutions using python 2.7, see: https://github.com/epequeno/python-for-informatics.
